#!/usr/bin/env python
import cPickle as pkl
import matplotlib.pyplot as plt
import numpy as np


#plot script which load pkl data

with open("./conductivity_RTA.pkl",'rb') as f:
    conductivity_RTA_pkl = pkl.load(f)

temps = range(0,500,10) 

plt.plot(temps, conductivity_RTA_pkl[:,0,0] ,label = "$\kappa_{11}$")
plt.plot(temps, conductivity_RTA_pkl[:,1,1] ,label = "$\kappa_{22}$")
plt.plot(temps, conductivity_RTA_pkl[:,2,2] ,label = "$\kappa_{33}$")

plt.xlabel("Temperature (K)",fontsize=12)
plt.ylabel("Thermal conductivity ($Wm^{-1}K^{-1}$)",fontsize=12)

plt.title("thermal conductivity RTA exapmle")
plt.legend()
plt.savefig("thermal_condu_RTA_pkl.pdf",bbox_inches='tight')




#plot script which load txt data

conductivity_RTA_txt = np.loadtxt("./conductivity_RTA.txt")


plt.plot(conductivity_RTA_txt[:,0], conductivity_RTA_txt[:,1] ,label = "$\kappa_{11}$")
plt.plot(conductivity_RTA_txt[:,0], conductivity_RTA_txt[:,5] ,label = "$\kappa_{22}$")
plt.plot(conductivity_RTA_txt[:,0], conductivity_RTA_txt[:,9] ,label = "$\kappa_{33}$")

plt.xlabel("Temperature (K)",fontsize=12)
plt.ylabel("Thermal conductivity ($Wm^{-1}K^{-1}$)",fontsize=12)

plt.title("thermal conductivity RTA exapmle")
plt.legend()
plt.savefig("thermal_condu_RTA_txt.pdf",bbox_inches='tight')

