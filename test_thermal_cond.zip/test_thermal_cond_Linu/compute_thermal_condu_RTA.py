#!/usr/bin/env python
import numpy as np
import cPickle as pkl
from constants import hbar, kB
from phonon_tools import Phonon
from conductivity import Conductivity, bedist
import itertools
from collections import OrderedDict

cd = Conductivity(
    struct="./input/poscar",   # poscar for the structure, same one used in computation of IFCs
    grid="4 4 4",          # both RTA and LBTE method needs to integrate over reduced reciprocal space, the grid is the mesh
#     grid="8 8 8",        # the grid is the mesh, "10 10 10" is generally good.  But please check the convergence with. 
#     grid="12 12 12",     # But please check the convergence with denser grid.  
    pgn="C1",              # pgn is not implemented yet, alway set C1 for this version.
    phi2="./input/PhiN_WS_2nd_loto.pkl",   # 2nd order IFCs
    phi3="./input/PhiN_WS_cub.pkl",        # 3rd order IFCs
    epsilon="./input/epsilon.yml",         # epsilon used for dipole-dipole effect in 2nd IFCs
    q_direction="1 0 0",                   # q_direction used for dipole-dipole effect in 2nd IFCs, always use this 
    )

temps = range(0,500,10)   # set the temprature list at which the thermal conductivity is computed

# LBTE method (solve the linearized BTE numeriallcy exactly by iteration method
# Kappa_LBTE = cd.thermal_conductivity_LBTE(temperature = temps)        

# with open("conductivity_LBTE.pkl","wb") as f:
#   pkl.dump(Kappa_LBTE,f,protocol=pkl.HIGHEST_PROTOCOL)


# RTA method (compute thermal conductivity by relax time approximation.
Kappa_RTA  = cd.thermal_conductivity_RTA(temperature = temps)

with open("conductivity_RTA.pkl","wb") as f:
  pkl.dump(Kappa_RTA ,f,protocol=pkl.HIGHEST_PROTOCOL)


#The result is a number array with shape [len(temp), 3 ,3 ].     [3,3] is the thermal conductivity tensor. 
